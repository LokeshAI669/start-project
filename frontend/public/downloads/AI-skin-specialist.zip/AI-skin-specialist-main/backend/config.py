"""
Configuration module for AI Skin Specialist backend.
Loads settings from environment variables / .env file.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables
BASE_DIR = Path(__file__).resolve().parent  # project root
load_dotenv(BASE_DIR / ".env")
load_dotenv(BASE_DIR / "simple.env")

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite+aiosqlite:///{BASE_DIR / 'data' / 'app.db'}")

# ---------------------------------------------------------------------------
# JWT Authentication
# ---------------------------------------------------------------------------
JWT_SECRET = os.getenv("JWT_SECRET", "change-me-in-production-please")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = int(os.getenv("JWT_EXPIRATION_HOURS", "72"))

# ---------------------------------------------------------------------------
# AI / API Keys
# ---------------------------------------------------------------------------
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
DEEPGRAM_API_KEY = os.getenv("DEEPGRAM_API_KEY", "")
GROQ_VISION_MODEL = os.getenv("GROQ_VISION_MODEL", "qwen/qwen3.6-27b")
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "whisper-large-v3")
DEEPGRAM_TTS_MODEL = os.getenv("DEEPGRAM_TTS_MODEL", "aura-2-thalia-en")

# ---------------------------------------------------------------------------
# Offline Mode
# ---------------------------------------------------------------------------
OFFLINE_MODE = os.getenv("OFFLINE_MODE", "false").lower() in ("true", "1", "yes")

# Path to GGUF model files (used only in offline mode)
LLAMA_MODEL_PATH = os.getenv("LLAMA_MODEL_PATH", "")
WHISPER_LOCAL_MODEL = os.getenv("WHISPER_LOCAL_MODEL", "base")  # tiny, base, small, medium, large

# ---------------------------------------------------------------------------
# Uploads / Data
# ---------------------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = DATA_DIR / "uploads"
AUDIO_DIR = DATA_DIR / "audio"
REPORTS_DIR = DATA_DIR / "reports"

# Ensure directories exist
for d in (DATA_DIR, UPLOADS_DIR, AUDIO_DIR, REPORTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# CORS
# ---------------------------------------------------------------------------
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
