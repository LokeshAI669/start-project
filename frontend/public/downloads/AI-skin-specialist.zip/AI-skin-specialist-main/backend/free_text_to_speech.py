import ctypes
import os
import platform
import subprocess
import time
from pathlib import Path
from gtts import gTTS


def play_audio(audio_filepath):
    audio_filepath = Path(audio_filepath).resolve()
    os_name = platform.system()

    if os_name == "Windows":
        try:
            alias = f"gtts_{int(time.time())}"
            mci = ctypes.windll.winmm.mciSendStringW
            mci(f"close {alias}", None, 0, 0)
            open_res = mci(f'open "{audio_filepath}" type mpegvideo alias {alias}', None, 0, 0)
            if open_res == 0:
                mci(f"play {alias} wait", None, 0, 0)
                mci(f"close {alias}", None, 0, 0)
                return
        except Exception:
            pass
        os.startfile(str(audio_filepath))
    elif os_name == "Darwin":
        subprocess.run(["afplay", str(audio_filepath)], check=False)
    else:
        subprocess.run(["mpg123", str(audio_filepath)], check=False)


def text_to_speech_with_gtts(input_text, output_filepath, language="en"):
    audioobj = gTTS(
        text=input_text,
        lang=language,
        slow=False
    )
    audioobj.save(output_filepath)
    return output_filepath


if __name__ == "__main__":
    input_text = "Hello, this is a test of the text-to-speech functionality. My name is AI with Hassan"
    output_filepath = "output_gtts.mp3"
    text_to_speech_with_gtts(input_text, output_filepath)
