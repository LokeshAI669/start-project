"""
RAG (Retrieval-Augmented Generation) engine for the AI Skin Specialist.

Uses ChromaDB as a local vector database to store and retrieve
dermatological guidelines from the knowledge_base/ directory.
The retrieved context is injected into the LLM prompt to ground
the AI doctor's responses in trusted medical information.
"""

import os
from pathlib import Path

try:
    import chromadb
    CHROMA_AVAILABLE = True
except ImportError as e:
    print(f"[WARN] ChromaDB disabled due to import error: {e}")
    CHROMA_AVAILABLE = False

BASE_DIR = Path(__file__).resolve().parent
KNOWLEDGE_DIR = BASE_DIR / "knowledge_base"
CHROMA_DB_DIR = BASE_DIR / "chroma_db"

# Module-level client and collection (initialized once)
_client = None
_collection = None


def _get_collection():
    """Return the ChromaDB collection, creating the client if needed."""
    global _client, _collection
    if not CHROMA_AVAILABLE:
        return None

    if _collection is not None:
        return _collection

    _client = chromadb.PersistentClient(path=str(CHROMA_DB_DIR))
    _collection = _client.get_or_create_collection(
        name="dermatology_guidelines",
        metadata={"hnsw:space": "cosine"},
    )
    return _collection


def _chunk_text(text, chunk_size=500, overlap=100):
    """
    Split text into overlapping chunks by character count.

    Each chunk is roughly `chunk_size` characters long, with `overlap`
    characters shared between consecutive chunks so that context at
    chunk boundaries is not lost.
    """
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


def initialize_knowledge_base():
    """
    Read all .txt files from the knowledge_base/ directory,
    split them into chunks, and upsert into the ChromaDB collection.

    This is idempotent — if chunks already exist in the persisted
    database they will be updated rather than duplicated.
    """
    collection = _get_collection()
    if not collection:
        print("[RAG] Skipping initialization, ChromaDB is disabled.")
        return

    if not KNOWLEDGE_DIR.exists():
        print(f"[RAG] Knowledge directory not found: {KNOWLEDGE_DIR}")
        return

    txt_files = list(KNOWLEDGE_DIR.glob("*.txt"))
    if not txt_files:
        print("[RAG] No .txt files found in knowledge_base/")
        return

    all_ids = []
    all_documents = []
    all_metadatas = []

    for txt_file in txt_files:
        content = txt_file.read_text(encoding="utf-8")
        chunks = _chunk_text(content)

        for i, chunk in enumerate(chunks):
            doc_id = f"{txt_file.stem}_chunk_{i}"
            all_ids.append(doc_id)
            all_documents.append(chunk)
            all_metadatas.append({
                "source": txt_file.name,
                "chunk_index": i,
            })

    if all_ids:
        collection.upsert(
            ids=all_ids,
            documents=all_documents,
            metadatas=all_metadatas,
        )

    print(f"[RAG] Knowledge base initialized: {len(all_ids)} chunks from {len(txt_files)} files.")


def retrieve_relevant_context(query, top_k=3):
    """
    Search the knowledge base for chunks most relevant to the query.

    Args:
        query: The patient's text description of their skin concern.
        top_k: Number of top matching chunks to return.

    Returns:
        A single string containing the concatenated relevant chunks,
        each separated by a blank line. Returns an empty string if
        the knowledge base is empty or not initialized.
    """
    collection = _get_collection()
    if not collection:
        return ""

    if collection.count() == 0:
        return ""

    results = collection.query(
        query_texts=[query],
        n_results=top_k,
    )

    documents = results.get("documents", [[]])[0]
    if not documents:
        return ""

    return "\n\n".join(documents)


if __name__ == "__main__":
    print("Initializing knowledge base...")
    initialize_knowledge_base()

    test_query = "I have a red scaly patch on my elbow that keeps coming back"
    print(f"\nTest query: '{test_query}'")
    print("\n--- Retrieved Context ---")
    context = retrieve_relevant_context(test_query)
    print(context)
