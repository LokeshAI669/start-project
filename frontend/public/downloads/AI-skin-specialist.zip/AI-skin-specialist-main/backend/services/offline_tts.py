"""
Offline text-to-speech using pyttsx3 (fully local, no API calls).

Requires:
  pip install pyttsx3
"""

from pathlib import Path


def tts_offline(text: str, output_filepath: str) -> str:
    """Convert text to speech locally using pyttsx3."""
    try:
        import pyttsx3
    except ImportError:
        raise RuntimeError(
            "Offline TTS requires pyttsx3. "
            "Install with: pip install pyttsx3"
        )

    engine = pyttsx3.init()

    # Configure voice properties
    engine.setProperty("rate", 160)   # Speaking speed
    engine.setProperty("volume", 0.9)

    # Try to use a female voice for the doctor
    voices = engine.getProperty("voices")
    for voice in voices:
        if "female" in voice.name.lower() or "zira" in voice.name.lower():
            engine.setProperty("voice", voice.id)
            break

    engine.save_to_file(text, output_filepath)
    engine.runAndWait()

    return output_filepath
