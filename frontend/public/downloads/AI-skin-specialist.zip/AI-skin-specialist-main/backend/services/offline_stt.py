"""
Offline speech-to-text using faster-whisper (CTranslate2 wrapper for whisper.cpp).

Requires:
  pip install faster-whisper
  Model will be auto-downloaded on first use.
"""

from pathlib import Path


def transcribe_offline(audio_filepath: str, language: str = "en") -> str:
    """Transcribe audio locally using faster-whisper."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise RuntimeError(
            "Offline STT requires faster-whisper. "
            "Install with: pip install faster-whisper"
        )

    from config import WHISPER_LOCAL_MODEL

    model = WhisperModel(
        WHISPER_LOCAL_MODEL,
        device="auto",  # uses GPU if available, else CPU
        compute_type="int8",
    )

    segments, info = model.transcribe(
        audio_filepath,
        language=language if language != "en" else None,
        beam_size=5,
    )

    text = " ".join(segment.text.strip() for segment in segments)
    return text
