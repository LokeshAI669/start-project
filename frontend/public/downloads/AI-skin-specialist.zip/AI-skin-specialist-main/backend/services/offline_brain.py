"""
Offline vision analysis using llama-cpp-python.
Provides the same interface as brain_of_the_doctor() but runs fully locally.

Requires:
  pip install llama-cpp-python
  A multimodal GGUF model file (e.g., llava-v1.6-mistral-7b.Q4_K_M.gguf)
  Set LLAMA_MODEL_PATH in .env to the path of the model file.
"""

import base64
import os
import sys
from io import BytesIO
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))


def brain_of_the_doctor_offline(
    patient_text,
    image_filepath=None,
    image_filepath_2=None,
    video_filepath=None,
    language="English",
):
    """Analyze skin image using a local llama.cpp multimodal model."""
    try:
        from llama_cpp import Llama
        from llama_cpp.llama_chat_format import Llava16ChatHandler
    except ImportError:
        raise RuntimeError(
            "Offline mode requires llama-cpp-python. "
            "Install with: pip install llama-cpp-python"
        )

    from config import LLAMA_MODEL_PATH

    if not LLAMA_MODEL_PATH or not Path(LLAMA_MODEL_PATH).exists():
        raise RuntimeError(
            f"LLAMA_MODEL_PATH not set or model file not found: {LLAMA_MODEL_PATH}. "
            "Download a multimodal GGUF model and set the path in .env"
        )

    # Encode image to base64 data URI
    from PIL import Image

    def encode_image(filepath):
        img = Image.open(filepath)
        img.thumbnail((512, 512))
        buf = BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=70)
        return f"data:image/jpeg;base64,{base64.b64encode(buf.getvalue()).decode()}"

    if not image_filepath:
        raise ValueError("Offline vision analysis requires a skin image.")

    image_uri = encode_image(image_filepath)

    prompt = (
        f"You are Dr. Smith, a board-certified dermatologist. "
        f"Examine this skin image and respond in {language}. "
        f"Patient says: '{patient_text}'. "
        f"Give a clinical assessment in 3-5 sentences. "
        f"Do NOT use markdown formatting."
    )

    # Load model
    chat_handler = Llava16ChatHandler(clip_model_path=LLAMA_MODEL_PATH)
    llm = Llama(
        model_path=LLAMA_MODEL_PATH,
        chat_handler=chat_handler,
        n_ctx=2048,
        n_gpu_layers=-1,  # Use GPU if available
    )

    response = llm.create_chat_completion(
        messages=[
            {"role": "system", "content": "You are a professional dermatologist."},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": image_uri}},
                ],
            },
        ],
        max_tokens=500,
    )

    return response["choices"][0]["message"]["content"] or ""


def chat_offline(system_prompt: str, messages: list[dict]) -> str:
    """Handle follow-up chat using a local text-only model."""
    try:
        from llama_cpp import Llama
    except ImportError:
        raise RuntimeError("Offline mode requires llama-cpp-python.")

    from config import LLAMA_MODEL_PATH

    if not LLAMA_MODEL_PATH or not Path(LLAMA_MODEL_PATH).exists():
        raise RuntimeError("LLAMA_MODEL_PATH not configured for offline mode.")

    llm = Llama(model_path=LLAMA_MODEL_PATH, n_ctx=2048, n_gpu_layers=-1)

    full_messages = [{"role": "system", "content": system_prompt}] + messages
    response = llm.create_chat_completion(messages=full_messages, max_tokens=300)

    return response["choices"][0]["message"]["content"] or ""
