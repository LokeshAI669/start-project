# Step1: Create API keys

# Step2: Create Client and send request
from deepgram import DeepgramClient
import os
from pathlib import Path
from dotenv import load_dotenv
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
import time


def convert_text_to_doctor_audio(text, output_filepath=None):
    deepgram_api_key = os.environ.get("DEEPGRAM_API_KEY")
    if not deepgram_api_key:
        raise ValueError("Missing DEEPGRAM_API_KEY in .env or environment")

    if output_filepath is None:
        # Save to AUDIO_DIR so files are served by /static/audio/
        try:
            from config import AUDIO_DIR
            filename = f"doctor_response_{int(time.time()*1000)}.mp3"
            output_filepath = AUDIO_DIR / filename
        except ImportError:
            # Fallback for standalone use
            filename = f"doctor_response_{int(time.time()*1000)}.mp3"
            output_filepath = BASE_DIR / filename
    else:
        output_filepath = Path(output_filepath)

    deepgram = DeepgramClient(api_key=deepgram_api_key)
    audio = deepgram.speak.v1.audio.generate(
        text=text,
        model=os.environ.get("DEEPGRAM_TTS_MODEL", "aura-2-thalia-en"),
        encoding="mp3",
    )

    with output_filepath.open("wb") as file:
        for chunk in audio:
            file.write(chunk)

    return output_filepath

import ctypes
import platform
import subprocess
import time


def play_audio(audio_filepath):
    audio_filepath = Path(audio_filepath).resolve()

    if platform.system() == "Windows":
        try:
            alias = f"audio_{int(time.time())}"
            mci = ctypes.windll.winmm.mciSendStringW
            mci(f"close {alias}", None, 0, 0)
            open_res = mci(f'open "{audio_filepath}" type mpegvideo alias {alias}', None, 0, 0)
            if open_res == 0:
                mci(f"play {alias} wait", None, 0, 0)
                mci(f"close {alias}", None, 0, 0)
                return
        except Exception:
            pass

        # Fallback to startfile if MCI API is restricted
        os.startfile(str(audio_filepath))
    elif platform.system() == "Darwin":
        subprocess.run(["afplay", str(audio_filepath)], check=False)
    else:
        subprocess.run(["mpg123", str(audio_filepath)], check=False)


if __name__ == "__main__":
    sample_text = "Hello, I am your AI skin specialist doctor. I have analyzed your skin symptoms and am here to help."
    print("Generating audio with Deepgram TTS...")
    out_file = convert_text_to_doctor_audio(sample_text)
    print(f"Audio generated successfully: {out_file}")
    print("Playing audio response...")
    play_audio(out_file)

