import base64
import os
import subprocess
import time
from io import BytesIO
from pathlib import Path

from dotenv import load_dotenv
# pyright: ignore [reportMissingImports]
from groq import Groq
from PIL import Image
from rag_engine import retrieve_relevant_context

load_dotenv()
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))


def encode_image_for_groq(filepath):
    image = Image.open(filepath)
    image.thumbnail((512, 512))

    buffer = BytesIO()
    image.convert("RGB").save(buffer, format="JPEG", quality=70)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def extract_video_frames(video_filepath, max_frames=2):
    frames_b64 = []
    if not video_filepath or not os.path.exists(video_filepath):
        return frames_b64

    temp_dir = Path(video_filepath).parent / "temp_video_frames"
    temp_dir.mkdir(exist_ok=True)
    out_pattern = str(temp_dir / "frame_%02d.jpg")

    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(video_filepath), "-vf", "fps=1/2", "-vframes", str(max_frames), out_pattern],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )

        for frame_file in sorted(temp_dir.glob("frame_*.jpg"))[:max_frames]:
            img_data = encode_image_for_groq(frame_file)
            frames_b64.append(img_data)
            try:
                frame_file.unlink()
            except Exception:
                pass
    except Exception as e:
        print(f"Video frame extraction note: {e}")

    return frames_b64


def brain_of_the_doctor(patient_text, image_filepath=None, image_filepath_2=None, video_filepath=None, language="English"):
    groq_api_key = os.environ.get("GROQ_API_KEY")
    if not groq_api_key:
        raise ValueError("Missing GROQ_API_KEY in .env or environment")

    if not image_filepath:
        raise ValueError("Vision analysis requires a skin image. Please upload a clear photo of your skin concern.")

    # Base64 encode the primary image
    image_b64 = encode_image_for_groq(image_filepath)

    image_b64_2 = None
    if image_filepath_2:
        image_b64_2 = encode_image_for_groq(image_filepath_2)

    # Extract video frames if video was provided
    video_frames_b64 = []
    if video_filepath and os.path.exists(video_filepath):
        video_frames_b64 = extract_video_frames(video_filepath)

    # Retrieve relevant medical guidelines from knowledge base
    rag_context = retrieve_relevant_context(patient_text)
    rag_section = ""
    if rag_context:
        rag_section = (
            "\n\nRelevant Medical Reference Material (use this to ground your response):\n"
            f"{rag_context}\n"
        )

    # Build prompt for authentic medical doctor evaluation
    if image_b64_2:
        prompt = (
            f"You are Dr. Smith, an expert, empathetic, board-certified dermatologist conducting a virtual telemedicine consultation. You MUST respond entirely in {language}.\n"
            f"Patient Statement: '{patient_text}'\n\n"
            f"{rag_section}"
            "Instructions:\n"
            "1. You are provided with two skin images for comparison (e.g., to track progress or worsening of a condition over time).\n"
            "2. Examine the provided skin images carefully and compare them.\n"
            "3. Provide a realistic clinical assessment based directly on what you observe visually (e.g., skin redness, scaling, rash pattern). Use the medical reference material above to give accurate, evidence-based guidance. State clearly if the condition appears to be improving, worsening, or staying the same.\n"
            "4. Offer actionable, practical care advice (such as gentle cleansing, avoiding harsh chemicals, keeping the skin hydrated) and reassure the patient.\n"
            "5. Recommend when to seek an in-person dermatology evaluation.\n"
            "6. Speak in a warm, professional voice as a real doctor talking directly to the patient.\n"
            "7. Do NOT use any asterisks (*), markdown headers, bullet points, or special characters because your output will be converted directly into audio speech.\n"
            "8. Keep your total response to 3-5 clear, natural sentences."
        )
    else:
        prompt = (
            f"You are Dr. Smith, an expert, empathetic, board-certified dermatologist conducting a virtual telemedicine consultation. You MUST respond entirely in {language}.\n"
            f"Patient Statement: '{patient_text}'\n\n"
            f"{rag_section}"
            "Instructions:\n"
            "1. Examine the provided skin image and video frames carefully.\n"
            "2. Provide a realistic clinical assessment based directly on what you observe visually in the image/video (e.g. skin redness, scaling, rash pattern, swelling, borders). Use the medical reference material above to give accurate, evidence-based guidance.\n"
            "3. Offer actionable, practical care advice (such as gentle cleansing, avoiding harsh chemicals, keeping the skin hydrated) and reassure the patient.\n"
            "4. Recommend when to seek an in-person dermatology evaluation.\n"
            "5. Speak in a warm, professional voice as a real doctor talking directly to the patient.\n"
            "6. Do NOT use any asterisks (*), markdown headers, bullet points, or special characters because your output will be converted directly into audio speech.\n"
            "7. Keep your total response to 3-5 clear, natural sentences."
        )

    # Build multimodal content payload
    content_payload = [{"type": "text", "text": prompt}]

    # Main image
    content_payload.append({
        "type": "image_url",
        "image_url": {
            "url": f"data:image/jpeg;base64,{image_b64}"
        }
    })

    # Second image
    if image_b64_2:
        content_payload.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{image_b64_2}"
            }
        })

    # Add 1 video frame if available to stay within token budget
    if video_frames_b64:
        content_payload.append({
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{video_frames_b64[0]}"
            }
        })

    model = os.environ.get("GROQ_VISION_MODEL", "qwen/qwen3.6-27b")
    client = Groq(api_key=groq_api_key)

    try:
        response = client.chat.completions.create(
            model=model,
            max_completion_tokens=2000,
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional board-certified dermatologist. Provide general skin care guidance, assessment, and reassurance based on visual observations.",
                },
                {
                    "role": "user",
                    "content": content_payload,
                },
            ],
        )

        content = response.choices[0].message.content or ""
        import re
        if "</think>" in content:
            content = content.split("</think>")[-1].strip()
        else:
            content = re.sub(r"<think>.*", "", content, flags=re.DOTALL).strip()
        if not content:
            raise ValueError("Vision response content was empty")
    except Exception as e:
        print(f"Vision API note: {e}")
        # Fallback to high-capacity model if vision call encounters an issue or empty response
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            max_tokens=800,
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional board-certified dermatologist. Give general skin care guidance, assessment, and advice.",
                },
                {
                    "role": "user",
                    "content": f"{prompt}\n[Visual assessment: Skin photo and video frames evaluated]",
                },
            ],
        )
        content = response.choices[0].message.content or ""
        content = content.strip()

    return content


if __name__ == "__main__":
    sample_img = os.path.join(os.path.dirname(__file__), "sample-image.png")
    sample_vid = os.path.join(os.path.dirname(__file__), "test-video.mp4")
    if os.path.exists(sample_img):
        print("Running brain_of_the_doctor with image and video...")
        result = brain_of_the_doctor(
            patient_text="I have noticed a red rash on my arm for two days. What should I do?",
            image_filepath=sample_img,
            video_filepath=sample_vid if os.path.exists(sample_vid) else None
        )
        print("\n--- Doctor Response ---")
        print(result)
    else:
        print("sample-image.png not found. Please provide an image to test.")
