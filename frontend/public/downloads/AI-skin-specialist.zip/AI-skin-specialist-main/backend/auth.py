"""
Authentication bypassed for simple mode.
Provides a dummy get_current_user that returns a default Guest User.
"""

import datetime
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database import User, get_db

# Empty router so main.py doesn't break
router = APIRouter(prefix="/api/auth", tags=["auth"])


async def get_current_user(db: AsyncSession = Depends(get_db)) -> User:
    """
    Returns a default Guest User, creating it if it doesn't exist.
    Bypasses all token checks.
    """
    email = "guest@example.com"
    
    result = await db.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    
    if not user:
        user = User(
            email=email,
            password_hash="bypassed",
            name="Guest User",
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        
    return user
