"""
FastAPI application entry point for AI Skin Specialist.
"""

import sys
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles



from config import AUDIO_DIR, CORS_ORIGINS, DATA_DIR, REPORTS_DIR, UPLOADS_DIR
from database import init_db

# Import routers
from auth import router as auth_router
from routes.analyze import router as analyze_router
from routes.chat import router as chat_router
from routes.history import router as history_router
from routes.tts import router as tts_router
from routes.stt import router as stt_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown logic."""
    # Initialize database tables
    await init_db()

    # Initialize RAG knowledge base
    try:
        from rag_engine import initialize_knowledge_base
        initialize_knowledge_base()
    except Exception as e:
        print(f"[WARN] RAG init: {e}")

    print("[OK] AI Skin Specialist backend ready")
    yield
    print("Shutting down...")


app = FastAPI(
    title="AI Skin Specialist API",
    description="Production API for AI-powered dermatology consultations",
    version="2.0.0",
    lifespan=lifespan,
)

# ---------------------------------------------------------------------------
# CORS
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Dev: allow all origins
    allow_credentials=False,  # Must be False when allow_origins=["*"]
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Static file serving (uploads, audio, reports)
# ---------------------------------------------------------------------------
app.mount("/static/uploads", StaticFiles(directory=str(UPLOADS_DIR)), name="uploads")
app.mount("/static/audio", StaticFiles(directory=str(AUDIO_DIR)), name="audio")
app.mount("/static/reports", StaticFiles(directory=str(REPORTS_DIR)), name="reports")

# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
app.include_router(auth_router)
app.include_router(analyze_router)
app.include_router(chat_router)
app.include_router(history_router)
app.include_router(tts_router)
app.include_router(stt_router)


@app.get("/api/health")
async def health_check():
    from config import OFFLINE_MODE
    return {
        "status": "healthy",
        "offline_mode": OFFLINE_MODE,
    }


@app.get("/api/config")
async def get_config():
    """Public config for the frontend."""
    from config import OFFLINE_MODE
    return {
        "offline_mode": OFFLINE_MODE,
        "languages": ["English", "Spanish", "Hindi", "French", "Arabic"],
    }
