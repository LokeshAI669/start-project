"""
Follow-up chat endpoint.
After the initial consultation, patients can ask follow-up questions.
The conversation history is maintained per consultation.
"""

import os
import sys
import time
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from auth import get_current_user
from config import AUDIO_DIR, GROQ_API_KEY, OFFLINE_MODE
from database import ChatMessage, Consultation, User, get_db

from voice_of_the_doctor import convert_text_to_doctor_audio
from free_text_to_speech import text_to_speech_with_gtts

router = APIRouter(prefix="/api/chat", tags=["chat"])

LANGUAGE_MAP = {
    "English": "en",
    "Spanish": "es",
    "Hindi": "hi",
    "French": "fr",
    "Arabic": "ar",
}


class ChatRequest(BaseModel):
    message: str
    generate_audio: bool = True


@router.post("/{consultation_id}")
async def send_message(
    consultation_id: int,
    body: ChatRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Load consultation with messages
    result = await db.execute(
        select(Consultation)
        .where(Consultation.id == consultation_id, Consultation.user_id == user.id)
        .options(selectinload(Consultation.messages))
    )
    consultation = result.scalar_one_or_none()
    if not consultation:
        raise HTTPException(status_code=404, detail="Consultation not found")

    # Build conversation history for context
    history = []
    for msg in sorted(consultation.messages, key=lambda m: m.created_at):
        role = "user" if msg.role == "patient" else "assistant"
        history.append({"role": role, "content": msg.content})

    # Add the new patient message
    history.append({"role": "user", "content": body.message})

    # System prompt with original consultation context
    system_prompt = (
        f"You are Dr. Smith, a board-certified dermatologist continuing a follow-up consultation. "
        f"You previously diagnosed the patient's skin concern. The patient's original concern was: "
        f"'{consultation.patient_text}'. Your original assessment was: '{consultation.doctor_text}'. "
        f"Now the patient has a follow-up question. Respond warmly and professionally in {consultation.language}. "
        f"Keep your response to 2-4 natural sentences. "
        f"Do NOT use asterisks, markdown, or bullet points — your response will be converted to audio."
    )

    # Generate follow-up response
    if OFFLINE_MODE:
        from services.offline_brain import chat_offline
        doctor_reply = chat_offline(system_prompt, history)
    else:
        from groq import Groq
        client = Groq(api_key=GROQ_API_KEY)
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            max_tokens=500,
            messages=[{"role": "system", "content": system_prompt}] + history,
        )
        doctor_reply = response.choices[0].message.content or ""
        # Strip thinking tags if present
        if "</think>" in doctor_reply:
            doctor_reply = doctor_reply.split("</think>")[-1].strip()

    # Generate audio for the response
    audio_url = ""
    doctor_audio_path = ""
    if body.generate_audio and doctor_reply:
        lang_code = LANGUAGE_MAP.get(consultation.language, "en")
        if OFFLINE_MODE:
            from services.offline_tts import tts_offline
            audio_filename = f"chat_{int(time.time() * 1000)}.mp3"
            doctor_audio_path = str(AUDIO_DIR / audio_filename)
            tts_offline(doctor_reply, doctor_audio_path)
        elif lang_code == "en":
            doctor_audio_path = str(convert_text_to_doctor_audio(doctor_reply))
        else:
            audio_filename = f"chat_gtts_{int(time.time() * 1000)}.mp3"
            doctor_audio_path = str(AUDIO_DIR / audio_filename)
            text_to_speech_with_gtts(doctor_reply, doctor_audio_path, language=lang_code)

        audio_url = f"/static/audio/{Path(doctor_audio_path).name}"

    # Save messages to DB
    msg_patient = ChatMessage(
        consultation_id=consultation_id,
        role="patient",
        content=body.message,
    )
    msg_doctor = ChatMessage(
        consultation_id=consultation_id,
        role="doctor",
        content=doctor_reply,
        audio_path=doctor_audio_path,
    )
    db.add_all([msg_patient, msg_doctor])
    await db.commit()

    return {
        "doctor_text": doctor_reply,
        "audio_url": audio_url,
    }


@router.get("/{consultation_id}/messages")
async def get_messages(
    consultation_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Consultation)
        .where(Consultation.id == consultation_id, Consultation.user_id == user.id)
        .options(selectinload(Consultation.messages))
    )
    consultation = result.scalar_one_or_none()
    if not consultation:
        raise HTTPException(status_code=404, detail="Consultation not found")

    messages = [
        {
            "id": msg.id,
            "role": msg.role,
            "content": msg.content,
            "audio_url": f"/static/audio/{Path(msg.audio_path).name}" if msg.audio_path else "",
            "created_at": msg.created_at.isoformat(),
        }
        for msg in sorted(consultation.messages, key=lambda m: m.created_at)
    ]

    return {"consultation_id": consultation_id, "messages": messages}
