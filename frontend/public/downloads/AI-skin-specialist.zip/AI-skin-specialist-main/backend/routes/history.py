"""
Consultation history endpoints.
List past consultations, view details, download reports.
"""

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from auth import get_current_user
from database import Consultation, User, get_db

router = APIRouter(prefix="/api/history", tags=["history"])


@router.get("")
async def list_consultations(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Consultation)
        .where(Consultation.user_id == user.id)
        .order_by(Consultation.created_at.desc())
    )
    consultations = result.scalars().all()

    return [
        {
            "id": c.id,
            "patient_text": c.patient_text[:120] + ("..." if len(c.patient_text) > 120 else ""),
            "doctor_text": c.doctor_text[:120] + ("..." if len(c.doctor_text) > 120 else ""),
            "language": c.language,
            "image_url": f"/static/uploads/{Path(c.image_path).name}" if c.image_path else "",
            "created_at": c.created_at.isoformat(),
        }
        for c in consultations
    ]


@router.get("/{consultation_id}")
async def get_consultation(
    consultation_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Consultation)
        .where(Consultation.id == consultation_id, Consultation.user_id == user.id)
        .options(selectinload(Consultation.messages))
    )
    consultation = result.scalar_one_or_none()
    if not consultation:
        raise HTTPException(status_code=404, detail="Consultation not found")

    messages = [
        {
            "id": msg.id,
            "role": msg.role,
            "content": msg.content,
            "audio_url": f"/static/audio/{Path(msg.audio_path).name}" if msg.audio_path else "",
            "created_at": msg.created_at.isoformat(),
        }
        for msg in sorted(consultation.messages, key=lambda m: m.created_at)
    ]

    return {
        "id": consultation.id,
        "patient_text": consultation.patient_text,
        "doctor_text": consultation.doctor_text,
        "language": consultation.language,
        "image_url": f"/static/uploads/{Path(consultation.image_path).name}" if consultation.image_path else "",
        "image2_url": f"/static/uploads/{Path(consultation.image_path_2).name}" if consultation.image_path_2 else "",
        "audio_url": f"/static/audio/{Path(consultation.audio_path).name}" if consultation.audio_path else "",
        "report_url": f"/static/reports/{Path(consultation.report_path).name}" if consultation.report_path else "",
        "created_at": consultation.created_at.isoformat(),
        "messages": messages,
    }


@router.get("/{consultation_id}/report")
async def download_report(
    consultation_id: int,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Consultation)
        .where(Consultation.id == consultation_id, Consultation.user_id == user.id)
    )
    consultation = result.scalar_one_or_none()
    if not consultation:
        raise HTTPException(status_code=404, detail="Consultation not found")

    if not consultation.report_path or not Path(consultation.report_path).exists():
        raise HTTPException(status_code=404, detail="Report not available")

    return FileResponse(
        path=consultation.report_path,
        filename=f"consultation_report_{consultation.id}.pdf",
        media_type="application/pdf",
    )
