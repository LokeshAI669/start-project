"""
Text-to-speech endpoint.
Routes to Deepgram (cloud) or pyttsx3 (offline) based on configuration.
"""

import sys
import time
from pathlib import Path

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from auth import get_current_user
from config import AUDIO_DIR, OFFLINE_MODE
from database import User
from voice_of_the_doctor import convert_text_to_doctor_audio
from free_text_to_speech import text_to_speech_with_gtts

router = APIRouter(prefix="/api/tts", tags=["tts"])


class TTSRequest(BaseModel):
    text: str
    language: str = "en"


@router.post("")
async def text_to_speech(body: TTSRequest, user: User = Depends(get_current_user)):
    if OFFLINE_MODE:
        from services.offline_tts import tts_offline
        audio_filename = f"tts_{int(time.time() * 1000)}.mp3"
        audio_path = str(AUDIO_DIR / audio_filename)
        tts_offline(body.text, audio_path)
    elif body.language == "en":
        audio_path = str(convert_text_to_doctor_audio(body.text))
    else:
        audio_filename = f"tts_gtts_{int(time.time() * 1000)}.mp3"
        audio_path = str(AUDIO_DIR / audio_filename)
        text_to_speech_with_gtts(body.text, audio_path, language=body.language)

    return {"audio_url": f"/static/audio/{Path(audio_path).name}"}
