"""
Speech-to-text endpoint.
Routes to Groq Whisper (cloud) or faster-whisper (offline) based on configuration.
"""

import shutil
import sys
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile

from auth import get_current_user
from config import AUDIO_DIR, OFFLINE_MODE
from database import User
from voice_of_the_patient import transcribe_patient_voice

router = APIRouter(prefix="/api/stt", tags=["stt"])


@router.post("")
async def speech_to_text(
    audio: UploadFile = File(...),
    language: str = Form("en"),
    user: User = Depends(get_current_user),
):
    # Save uploaded audio
    ext = Path(audio.filename or "audio.webm").suffix or ".webm"
    filename = f"stt_{uuid.uuid4().hex[:12]}{ext}"
    audio_path = str(AUDIO_DIR / filename)
    with open(audio_path, "wb") as f:
        shutil.copyfileobj(audio.file, f)

    if OFFLINE_MODE:
        from services.offline_stt import transcribe_offline
        text = transcribe_offline(audio_path, language=language)
    else:
        text = transcribe_patient_voice(audio_path, language=language)

    return {"text": text}
