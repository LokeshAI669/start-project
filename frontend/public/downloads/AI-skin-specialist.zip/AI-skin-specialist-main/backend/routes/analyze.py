"""
Skin analysis endpoint — the core consultation workflow.
Accepts image + audio/text, runs the AI doctor, returns response + audio + PDF.
"""

import shutil
import time
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from auth import get_current_user
from config import (
    AUDIO_DIR,
    OFFLINE_MODE,
    REPORTS_DIR,
    UPLOADS_DIR,
)
from database import ChatMessage, Consultation, User, get_db


from brain_of_the_doctor_groq import brain_of_the_doctor
from voice_of_the_doctor import convert_text_to_doctor_audio
from voice_of_the_patient import transcribe_patient_voice
from pdf_generator import generate_consultation_report
from free_text_to_speech import text_to_speech_with_gtts
from rag_engine import retrieve_relevant_context

router = APIRouter(prefix="/api", tags=["analyze"])

LANGUAGE_MAP = {
    "English": "en",
    "Spanish": "es",
    "Hindi": "hi",
    "French": "fr",
    "Arabic": "ar",
}


def _save_upload(upload: UploadFile, dest_dir: Path, prefix: str = "") -> str:
    """Save an uploaded file and return the path."""
    ext = Path(upload.filename or "file").suffix or ".bin"
    filename = f"{prefix}{uuid.uuid4().hex[:12]}{ext}"
    dest = dest_dir / filename
    with open(dest, "wb") as f:
        shutil.copyfileobj(upload.file, f)
    return str(dest)


@router.post("/analyze")
async def analyze(
    image: UploadFile = File(...),
    audio: UploadFile | None = File(None),
    video: UploadFile | None = File(None),
    image2: UploadFile | None = File(None),
    text_input: str = Form(""),
    language: str = Form("English"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # --- Save uploaded image ---
    image_path = _save_upload(image, UPLOADS_DIR, prefix="img_")

    # --- Save optional second image ---
    image_path_2 = ""
    if image2 and image2.filename:
        image_path_2 = _save_upload(image2, UPLOADS_DIR, prefix="img2_")

    # --- Save optional video ---
    video_path = ""
    if video and video.filename:
        video_path = _save_upload(video, UPLOADS_DIR, prefix="vid_")

    # --- Get patient text (from audio or typed text) ---
    lang_code = LANGUAGE_MAP.get(language, "en")
    patient_text = ""

    if audio and audio.filename:
        audio_input_path = _save_upload(audio, AUDIO_DIR, prefix="patient_")
        if OFFLINE_MODE:
            from services.offline_stt import transcribe_offline
            patient_text = transcribe_offline(audio_input_path, language=lang_code)
        else:
            patient_text = transcribe_patient_voice(audio_input_path, language=lang_code)
    elif text_input.strip():
        patient_text = text_input.strip()
    else:
        raise HTTPException(status_code=400, detail="Please provide audio or text describing your skin concern.")

    # --- Run AI Doctor ---
    if OFFLINE_MODE:
        from services.offline_brain import brain_of_the_doctor_offline
        doctor_text = brain_of_the_doctor_offline(
            patient_text=patient_text,
            image_filepath=image_path,
            image_filepath_2=image_path_2 or None,
            video_filepath=video_path or None,
            language=language,
        )
    else:
        doctor_text = brain_of_the_doctor(
            patient_text=patient_text,
            image_filepath=image_path,
            image_filepath_2=image_path_2 or None,
            video_filepath=video_path or None,
            language=language,
        )

    # --- Generate doctor audio ---
    if OFFLINE_MODE:
        from services.offline_tts import tts_offline
        audio_filename = f"doctor_{int(time.time() * 1000)}.mp3"
        doctor_audio_path = str(AUDIO_DIR / audio_filename)
        tts_offline(doctor_text, doctor_audio_path)
    elif lang_code == "en":
        doctor_audio_path = str(convert_text_to_doctor_audio(doctor_text))
    else:
        audio_filename = f"doctor_gtts_{int(time.time() * 1000)}.mp3"
        doctor_audio_path = str(AUDIO_DIR / audio_filename)
        text_to_speech_with_gtts(doctor_text, doctor_audio_path, language=lang_code)

    # --- Generate PDF report ---
    report_path = generate_consultation_report(
        patient_text=patient_text,
        doctor_text=doctor_text,
        image_path=image_path,
        image_path_2=image_path_2 or None,
    )

    # --- Save consultation to database ---
    consultation = Consultation(
        user_id=user.id,
        patient_text=patient_text,
        doctor_text=doctor_text,
        language=language,
        image_path=image_path,
        image_path_2=image_path_2,
        audio_path=doctor_audio_path,
        report_path=report_path,
    )
    db.add(consultation)

    # Save initial messages to chat history
    msg_patient = ChatMessage(
        consultation=consultation,
        role="patient",
        content=patient_text,
    )
    msg_doctor = ChatMessage(
        consultation=consultation,
        role="doctor",
        content=doctor_text,
        audio_path=doctor_audio_path,
    )
    db.add_all([msg_patient, msg_doctor])
    await db.commit()
    await db.refresh(consultation)

    return {
        "consultation_id": consultation.id,
        "patient_text": patient_text,
        "doctor_text": doctor_text,
        "audio_url": f"/static/audio/{Path(doctor_audio_path).name}",
        "report_url": f"/static/reports/{Path(report_path).name}",
        "image_url": f"/static/uploads/{Path(image_path).name}",
    }
