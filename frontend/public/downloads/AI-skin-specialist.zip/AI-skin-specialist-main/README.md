# 🩺 AI Skin Specialist

**AI-powered dermatology consultation platform** with voice, image, and video analysis. Built with a **Next.js** frontend and **FastAPI** backend, featuring authentication, follow-up chat, consultation history, offline mode, and Docker support.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔬 **AI Skin Analysis** | Upload skin images for instant AI-powered dermatological assessment |
| 🎤 **Voice Input** | Record or upload audio describing your symptoms (5 languages) |
| 💬 **Follow-up Chat** | Continue the conversation with follow-up questions after diagnosis |
| 📋 **Consultation History** | Track skin health over time with full history and search |
| 🔐 **Authentication** | JWT-based login with encrypted passwords and per-user data |
| 🔒 **Offline Mode** | Process everything locally with llama.cpp + whisper.cpp + pyttsx3 |
| 📄 **PDF Reports** | Download detailed consultation reports to share with your doctor |
| ⚠️ **Medical Disclaimer** | Mandatory consent checkbox before using AI analysis |
| 🐳 **Docker Support** | One-command deployment with Docker Compose |
| 🌍 **Multi-language** | English, Spanish, Hindi, French, Arabic |

---

## 🏗️ Architecture

```
┌─────────────────────┐     ┌─────────────────────────┐
│   Next.js Frontend  │────▶│    FastAPI Backend       │
│   (Port 3000)       │     │    (Port 8000)           │
│                     │     │                          │
│  • Landing Page     │     │  • /api/auth/*           │
│  • Login/Register   │     │  • /api/analyze          │
│  • Dashboard        │     │  • /api/chat/{id}        │
│  • Follow-up Chat   │     │  • /api/history          │
│  • History          │     │  • /api/tts              │
│  • Consent Modal    │     │  • /api/stt              │
└─────────────────────┘     └────────────┬────────────┘
                                         │
                            ┌────────────▼────────────┐
                            │   Python Services       │
                            │                          │
                            │  • Groq Vision API       │
                            │  • Deepgram TTS          │
                            │  • ChromaDB (RAG)        │
                            │  • PDF Generator         │
                            │  • Offline: llama.cpp    │
                            │  • Offline: whisper.cpp  │
                            │  • Offline: pyttsx3      │
                            └─────────────────────────┘
```

---

## 🚀 Quick Start

### Option 1: Docker (Recommended)

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env with your GROQ_API_KEY and DEEPGRAM_API_KEY

# 2. Run with Docker Compose
docker-compose up --build

# 3. Open http://localhost:3000
```

### Option 2: Manual Setup

**Prerequisites:** Python 3.11+, Node.js 20+, FFmpeg

```bash
# 1. Backend
pip install -r backend/requirements.txt
cp .env.example .env  # Edit with your API keys
uvicorn backend.main:app --reload --port 8000

# 2. Frontend (in a new terminal)
cd frontend
npm install
npm run dev

# 3. Open http://localhost:3000
```

---

## 🔒 Offline Mode (Privacy)

For maximum privacy, enable offline mode so **no data leaves your computer**:

1. Install offline dependencies:
   ```bash
   pip install llama-cpp-python faster-whisper pyttsx3
   ```

2. Download a multimodal GGUF model (e.g., LLaVA)

3. Set in your `.env`:
   ```
   OFFLINE_MODE=true
   LLAMA_MODEL_PATH=/path/to/your/model.gguf
   WHISPER_LOCAL_MODEL=base
   ```

---

## 📁 Project Structure

```
AI-skin-specialist/
├── backend/                    # FastAPI backend
│   ├── main.py                 # App entry point
│   ├── config.py               # Settings & env vars
│   ├── database.py             # SQLAlchemy models (User, Consultation, Chat)
│   ├── auth.py                 # JWT authentication
│   ├── routes/
│   │   ├── analyze.py          # POST /api/analyze
│   │   ├── chat.py             # POST /api/chat/{id}
│   │   ├── history.py          # GET /api/history
│   │   ├── tts.py              # POST /api/tts
│   │   └── stt.py              # POST /api/stt
│   ├── services/
│   │   ├── offline_brain.py    # Local llama.cpp vision
│   │   ├── offline_stt.py      # Local whisper
│   │   └── offline_tts.py      # Local pyttsx3
│   └── requirements.txt
├── frontend/                   # Next.js frontend
│   └── src/
│       ├── app/
│       │   ├── page.js         # Landing page
│       │   ├── login/          # Login page
│       │   ├── register/       # Register page
│       │   ├── dashboard/      # Consultation dashboard
│       │   │   └── chat/[id]/  # Follow-up chat
│       │   └── history/        # Consultation history
│       ├── components/
│       │   ├── Navbar.js       # Navigation bar
│       │   ├── ConsentModal.js # Medical disclaimer
│       │   ├── AudioRecorder.js# Voice recording
│       │   ├── ImageUpload.js  # Drag-and-drop upload
│       │   └── ChatBubble.js   # Chat message bubble
│       ├── context/
│       │   └── AuthContext.js   # JWT auth state
│       └── lib/
│           └── api.js          # API client
├── brain_of_the_doctor_groq.py # AI vision analysis (Groq)
├── voice_of_the_patient.py     # Speech-to-text (Groq Whisper)
├── voice_of_the_doctor.py      # Text-to-speech (Deepgram)
├── rag_engine.py               # RAG with ChromaDB
├── pdf_generator.py            # PDF report generation
├── Dockerfile.backend          # Backend Docker image
├── Dockerfile.frontend         # Frontend Docker image
├── docker-compose.yml          # One-command deployment
├── .env.example                # Environment template
└── main.py                     # Legacy Gradio app (still works)
```

---

## ⚠️ Disclaimer

This application is for **informational purposes only** and is **not a substitute** for professional medical advice, diagnosis, or treatment. Always consult a licensed dermatologist for medical concerns.

---

## 📜 License

MIT
"# AI-skin-specialist" 
